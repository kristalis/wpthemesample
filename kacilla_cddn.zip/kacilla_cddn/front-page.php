<?php
/**
 * The main template file
 *
 * This is the most generic template file in a WordPress theme
 * and one of the two required files for a theme (the other being style.css).
 * It is used to display a page when nothing more specific matches a query.
 * E.g., it puts together the home page when no home.php file exists.
 *
 * @link https://codex.wordpress.org/Template_Hierarchy
 *
 * @package cDDn
 */

get_header(); ?>



    <section class="bg-primary" id="about">
      <div class="container">
        <div class="row">
          <div class="col-lg-8 mx-auto text-center">
            <h2 class="section-heading text-white">CDDNI LAUNCH 2017</h2>
            <hr class="light">
            <p class="text-faded">Ready to start learning web applications and software development or take your development to the next level? That's a blessing! 
              The network for Christian Developers and Designers has been established to teach, provide and share knowledge. 
              <br>If you have interest in learning then why not register for our upcoming launch to learn more about the benefits  of joining the network.
             Enjoy a full english breakfast during the workshop. <br><b>Seats are limited so it is on a First Come First Served basis</b></p>
            <a class="btn btn-default btn-xl js-scroll-trigger" href="#register">Register for the Launch Today</a>
          </div>
        </div>
      </div>
    </section>

    <section id="services">
      <div class="container">
        <div class="row">
          <div class="col-lg-12 text-center">
            <h2 class="section-heading">What to Expect At the Launch</h2>
            <hr class="primary">
          </div>
        </div>
      </div>
      <div class="container">
        <div class="row">
          <div class="col-lg-3 col-md-6 text-center">
            <div class="service-box">
              <i class="fa fa-4x fa-diamond text-primary sr-icons"></i>
              <h3>Full English Breakfast</h3>
              <p class="text-muted">Included in your registeration fees is a Full English Breakfast </p>
            </div>
          </div>
          <div class="col-lg-3 col-md-6 text-center">
            <div class="service-box">
              <i class="fa fa-4x fa-paper-plane text-primary sr-icons"></i>
              <h3>Vision of the Network</h3>
              <p class="text-muted">We will layout our vision and mission for the network</p>
            </div>
          </div>
          <div class="col-lg-3 col-md-6 text-center">
            <div class="service-box">
              <i class="fa fa-4x fa-newspaper-o text-primary sr-icons"></i>
              <h3>Benefits of the Network</h3>
              <p class="text-muted">The benefits to expect as a loyal member</p>
            </div>
          </div>
          <div class="col-lg-3 col-md-6 text-center">
            <div class="service-box">
              <i class="fa fa-4x fa-heart text-primary sr-icons"></i>
              <h3>Your Role as a Member</h3>
              <p class="text-muted">What you will be learning as a member</p>
            </div>
          </div>
        </div>
      </div>
    </section>

<?php
//get_sidebar();
get_footer();

<?php
/**
 * The template for displaying the footer
 *
 * Contains the closing of the #content div and all content after.
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package cDDn
 */

?>
	
	   <div class="call-to-action bg-dark">
     <section id="register">
      <div class="container text-center">
        <h2 style="text-red">Register Now!</h2>  <h2> Date :  Saturday 4th November | Time :  10:00am</h2><h3>  Venue:  Peartree Lodge, Milton Keynes</h3><br>
        <a class="btn btn-default btn-xl sr-button" href="https://www.paypal.com/cgi-bin/webscr?cmd=_s-xclick&hosted_button_id=376BXAPLZ5ZDL">Click to Register Now - Limited Space</a>
           <br> **FULL ENGLISH BREAKFAST included
     </div>
      </section>
    </div>
    
<div>
     <section>
      <div class="container ">
        <div class="row">
            <div class="col-lg-8">
                    <a href="https://www.amazon.co.uk/Layman-Steps-beginners-beautiful-application-ebook/dp/B0725XDW5F" target=_blank><img src="https://images-eu.ssl-images-amazon.com/images/I/416czP4YSOL._SY346_.jpg" alt="Click here to buy layman's steps to Laravel & Bootstrap"></a>
                    <a href="https://www.amazon.co.uk/Layman-Steps-beginners-beautiful-WordPress-ebook/dp/B071WK1DSN" target=_blank><img src="https://images-eu.ssl-images-amazon.com/images/I/41IIh0kv1jL._SY346_.jpg" alt="Click here to buy layman's steps to Laravel & Bootstrap"></a>
                    <a href="https://www.amazon.co.uk/Layman-Steps-beginners-building-application-ebook/dp/B072PWQW25" target=_blank><img src="https://images-eu.ssl-images-amazon.com/images/I/410ybUmG-KL._SY346_.jpg" alt="Click here to buy layman's steps to Laravel & MySQL"></a>
                      
                </div>
                <div class="col-lg-4  text-center">
        <h2><em>Find out How these little books published on Amazon is going to make me over £30,000 in a year and led to the establishment of the <br>Christian Developers and Designers Network International</em></h2>
                <a class="btn btn-primary btn-xl js-scroll-trigger" href="https://www.paypal.com/cgi-bin/webscr?cmd=_s-xclick&hosted_button_id=376BXAPLZ5ZDL">Register Now</a>
                </div>
                
     </div>
      </section>
    </div>
   
      <section id="contacts">
        <div class="container">
            <div class="row">
                <div class="col-lg-12 text-center">
                    <h2 class="section-heading">Contact the Network</h2>
                    <h3 class="section-subheading text-muted"></h3>
                </div>
            </div>
            <div class="row">
                <div class="col-lg-12">
                    <form name="sentMessage" id="contactForm" novalidate>
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <input type="text" class="form-control" placeholder="Your Name *" id="name" required data-validation-required-message="Please enter your name.">
                                    <p class="help-block text-danger"></p>
                                </div>
                                <div class="form-group">
                                    <input type="email" class="form-control" placeholder="Your Email *" id="email" required data-validation-required-message="Please enter your email address.">
                                    <p class="help-block text-danger"></p>
                                </div>
                                <div class="form-group">
                                    <input type="tel" class="form-control" placeholder="Your Phone *" id="phone" required data-validation-required-message="Please enter your phone number.">
                                    <p class="help-block text-danger"></p>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <textarea class="form-control" placeholder="Your Message *" id="message" required data-validation-required-message="Please enter a message."></textarea>
                                    <p class="help-block text-danger"></p>
                                </div>
                            </div>
                            <div class="clearfix"></div>
                            <div class="col-lg-12 text-center">
                                <div id="success"></div>
                                <button type="submit" class="btn btn-xl">Send Message</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </section>
     <footer>
        <div class="container">
            <div class="row">
                <div class="col-md-4">
                        <a href="<?php echo esc_url( __( 'http://www.cddni.com/', 'Christian Developers Designers Network International' ) ); ?>"><?php
                /* translators: %s: CMS name, i.e. WordPress. */
                printf( esc_html__( '&copy; %s', 'Christian Developers Designers Network International' ), 'CDDNI, 2017' );
            ?></a>
                   
                </div>
               
                <div class="col-md-8 text-right">
                 <a href="<?php echo esc_url( __( 'https://kacilla.com/', 'kacilla_cddn' ) ); ?>">
                  <?php printf( esc_html__( 'Proudly developed by %s', 'kacilla_cddn' ), 'Kacilla' ); ?></a>               </div>
            </div>
        </div>
    </footer>

  

 

<?php wp_footer(); ?>

</body>
</html>
